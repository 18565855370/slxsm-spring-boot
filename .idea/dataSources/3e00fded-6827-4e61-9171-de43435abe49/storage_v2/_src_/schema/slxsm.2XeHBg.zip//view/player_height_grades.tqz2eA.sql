create definer = test@`%` view player_height_grades as
select `p`.`player_name` AS `player_name`, `p`.`height` AS `height`, `h`.`height_level` AS `height_level`
from (`slxsm`.`player` `p`
         join `slxsm`.`height_grades` `h` on ((`p`.`height` between `h`.`height_lowest` and `h`.`height_highest`)));

