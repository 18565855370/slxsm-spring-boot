create
    definer = test@`%` procedure get_hero_sources(OUT max_max_up float, OUT min_max_mp float, OUT avg_max_attack float,
                                                  IN s varchar(255))
BEGIN
    SELECT MAX(hp_max),min(mp_max),avg(attack_max) from heros
        where role_main = s INTO max_max_up,min_max_mp,avg_max_attack;
END;

