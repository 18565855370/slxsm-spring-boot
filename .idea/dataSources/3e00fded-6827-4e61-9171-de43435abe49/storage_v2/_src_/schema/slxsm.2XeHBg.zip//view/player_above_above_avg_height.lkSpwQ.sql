create definer = test@`%` view player_above_above_avg_height as
select `slxsm`.`player`.`player_id` AS `player_id`, `slxsm`.`player`.`height` AS `height`
from `slxsm`.`player`
where (`slxsm`.`player`.`height` >
       (select avg(`player_above_avg_height`.`height`) from `slxsm`.`player_above_avg_height`));

