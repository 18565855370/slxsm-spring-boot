create definer = test@`%` view player_team as
select concat(`slxsm`.`player`.`player_name`, '(', `slxsm`.`team`.`team_name`, ')') AS `player_team`
from (`slxsm`.`player`
         join `slxsm`.`team`)
where (`slxsm`.`player`.`team_id` = `slxsm`.`team`.`team_id`);

