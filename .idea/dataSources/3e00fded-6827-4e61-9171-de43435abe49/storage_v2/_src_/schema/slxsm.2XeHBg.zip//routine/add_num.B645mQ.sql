create
    definer = test@`%` procedure add_num(IN n int)
BEGIN
    DECLARE i INT;
    DECLARE sum INT;

    SET i = 1;
    SET sum = 0;
    WHILE i < n DO
        SET sum = sum + 1;
        SET i = i + 1;
    end while;
    SELECT sum;
end;

