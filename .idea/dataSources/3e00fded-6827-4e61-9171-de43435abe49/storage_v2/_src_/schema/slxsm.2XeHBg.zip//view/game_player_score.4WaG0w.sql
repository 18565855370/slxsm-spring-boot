create definer = test@`%` view game_player_score as
select `slxsm`.`player_score`.`game_id`                                                    AS `game_id`,
       `slxsm`.`player_score`.`player_id`                                                  AS `player_id`,
       ((`slxsm`.`player_score`.`shoot_hits` - `slxsm`.`player_score`.`shoot_3_hits`) * 2) AS `shoot_2_points`,
       (`slxsm`.`player_score`.`shoot_3_hits` * 3)                                         AS `shoot_3_points`,
       `slxsm`.`player_score`.`shoot_p_hits`                                               AS `shoot_p_hits`,
       `slxsm`.`player_score`.`score`                                                      AS `score`
from `slxsm`.`player_score`;

